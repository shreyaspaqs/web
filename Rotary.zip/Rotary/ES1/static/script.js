// function updateTemperatureBar(temperatureValue) {
//     var temperatureBar = document.querySelector('.temperature .skill-per');

//     // Update percentage value and max-width
//     temperatureBar.setAttribute('per', temperatureValue + '°C');
//     temperatureBar.style.maxWidth = temperatureValue + '%';

//     // Update color based on temperature range
//     if (temperatureValue >= 0 && temperatureValue <= 25) {
//         temperatureBar.style.backgroundColor = 'green';
//     } else if (temperatureValue > 25 && temperatureValue <= 50) {
//         temperatureBar.style.backgroundColor = 'yellow';
//     } else if (temperatureValue > 50 && temperatureValue <= 75) {
//         temperatureBar.style.backgroundColor = 'orange';
//     } else {
//         temperatureBar.style.backgroundColor = 'red';
//     }

//     // Update the label with temperature and degree symbol (°C)
//     var temperatureLabel = document.querySelector('.temperature .skill-name');
//     temperatureLabel.innerHTML = 'Temperature: ' + temperatureValue + '°C';
// }

// // Example data from the backend (you can replace this with your actual data)
// var backendData = {
//     temperature: 20
// };

// // Call the function with the temperature value from the backend
//         updateTemperatureBar(backendData.temperature);





        // document.addEventListener("DOMContentLoaded", function() {
        //     // Get the AQI value element
        //     const aqiElement = document.querySelector('.aqi_val');

        //     // Get the AQI value from the text content
        //     const aqiValue = parseInt(aqiElement.textContent.replace('AQI:', '').trim(), 10);

        //     // Define color ranges
        //     const colorRanges = [
        //         { min: 0, max: 50, color: '#458806' },
        //         { min: 51, max: 100, color: '#73b916' },
        //         { min: 101, max: 200, color: '#f6cf20' },
        //         { min: 201, max: 300, color: '#db7e04' },
        //         { min: 301, max: 400, color: '#da4105' },
        //         { min: 401, max: 500, color: '#b90606' },
        //     ];

        //     // Function to update text color based on AQI value
        //     function updateTextColor() {
        //         let textColor = '#ffffff'; // Default text color

        //         // Find the appropriate color range
        //         for (const range of colorRanges) {
        //             if (aqiValue >= range.min && aqiValue <= range.max) {
        //                 textColor = (range.max - range.min <= 50) ? '#000000' : '#ffffff'; // Adjust text color based on range size
        //                 break;
        //             }
        //         }

        //         // Update text color
        //         aqiElement.style.color = textColor;
        //     }

        //     // Call the function initially
        //     updateTextColor();
        // });


//        fetch('https://app.myairmyhealth.com/airengine/v5/device/detail/7d4100b4-2a6e-45c4-9146-545ac78ee19d')
//        .then(response => response.json())
//        .then(data => {
//            // Get the devices array from the response
//            const devices = data.devices;
//
//            // Get the dropdown element
//            const dropdown = document.getElementById('deviceDropdown');
//
//            // Loop through devices and create list items
//            devices.forEach(device => {
//                const listItem = document.createElement('li');
//                listItem.innerHTML = `<a class="dropdown-item" href="#">${device.deviceName}</a>`;
//                dropdown.appendChild(listItem);
//            });
//        })
//        .catch(error => console.error('Error fetching data:', error));
