function logoutUser() {
    // You can perform any logout-related actions here
    // For example, redirecting to a login page or clearing session data

    // For demonstration purposes, let's just show an alert
    window.location.href='../login/loginpage.html';
    // alert('Logged out successfully!');
    
}