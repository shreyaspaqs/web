let token;

// ... [your existing HTML and script]
function test(e) {
  console.log("Value is " + e.value);
  let device_id = e.value;
  const url =`https://app.myairmyhealth.com/airengine/v5/device/specs//${device_id}/ELCI-5031fec5-4abf-4f8a-a07f-8398364850a4`;

  // const authToken = api();
  authToken = token;
  console.log("authToken is " + authToken);

  fetch(url, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${authToken}`,
      "X-forwarded-for": "14.143.117.134",
      "Content-Type": "application/json",
      // Add any other headers if needed
    },
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json(); // or response.text() if the response is not JSON
    })
    .then((data) => {
      // Handle the data from the response
      console.log("api data is" + data);
    })
    .catch((error) => {
      // Handle errors during the fetch
      console.error("Fetch error:", error);
    });
}

function getData(tokens) {
  const ipAddress = "122.166.165.11";
  const deviceURL =
    "https://app.myairmyhealth.com/airengine/v5/device/detail/7d4100b4-2a6e-45c4-9146-545ac78ee19d";
  const endpointURL =
    "https://app.myairmyhealth.com/airengine/v5/pollutiondata/lastdata/7d4100b4-2a6e-45c4-9146-545ac78ee19d";
  const aqiEndpointURL =
    "https://app.myairmyhealth.com/airengine/v5/aqi/location/7d4100b4-2a6e-45c4-9146-545ac78ee19d?lat=12.845444&lng=77.661011";
  const feelsLikeEndpointURL =
    "https://app.myairmyhealth.com/airengine/dashboard/feelslike/a18483a6-e668-4313-b62b-98ef7c22e804?type=devId&in1=SUNTech-ac22a6b5-edcf-42d2-ac96-536385e2562a";
  // const feelsLikeApiKey = 'a18483a6-e668-4313-b62b-98ef7c22e804?type=devId&in1=SUNTech-7ef448a3-19ff-4cf7-a20c-e65777c737d2';
  const apiKey = tokens;

  fetch(endpointURL, {
    method: "GET",
    headers: {
      Authorization: apiKey,
      "X-Forwarded-For": "14.143.117.134",
      "Content-Type": "application/json",
      // Add other headers if required
    },
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json(); // or response.text() or response.blob(), based on the expected response type
    })
    .then((data) => {
      // Use the response data
      //console.log("Fetched data: ", data); // Display or use the returned data
      //   console.log("element is" + JSON.stringify(data[3]));

      
      let devId = data[5].devId;
   
      console.log("devid is" + JSON.stringify(devId));
      let devHeading = "<strong>Device id:</strong>"
      // Use [0] to access the first element of the collection
      document.getElementsByClassName("devid")[0].innerHTML = devHeading + devId;

      const curdate = new Date();
      document.getElementById("date-display").innerHTML = curdate;

    
    

      // Assuming temperatureValueFromAPI contains the temperature value from your API
      let temperatureValueFromAPI = data[5].parameters[2].value.toFixed(1);

      // Function to update temperature bar
      function updateTemperatureBar(temperatureValue) {
        var temperatureBar = document.querySelector(".temperature .skill-per");

        // Update percentage value and max-width
        temperatureBar.setAttribute("per", temperatureValue + "°C");
        temperatureBar.style.maxWidth = temperatureValue + "%";

        // Update color based on temperature range
        if (temperatureValue >= 0 && temperatureValue <= 25) {
          temperatureBar.style.backgroundColor = "green";
        } else if (temperatureValue > 25 && temperatureValue <= 50) {
          temperatureBar.style.backgroundColor = "yellow";
        } else if (temperatureValue > 50 && temperatureValue <= 75) {
          temperatureBar.style.backgroundColor = "orange";
        } else {
          temperatureBar.style.backgroundColor = "red";
        }

        // Update the label with temperature and degree symbol (°C)
        var temperatureLabel = document.querySelector(
          ".temperature .skill-name"
        );
        temperatureLabel.innerHTML = "Temperature: " + temperatureValue + "°C";
      }

      // Call the function with the temperature value from the API
      updateTemperatureBar(temperatureValueFromAPI);


     
    let o3 = data[5].parameters[3].value.toFixed(1);
    let o3Heading = "O3: ";
    let o3WithValueUnit = o3 + " ppm";
    document.querySelector(".text-top1.o3").innerHTML = o3Heading + o3WithValueUnit;

    let co2 = data[5].parameters[4].value.toFixed(1);
    let co2Heading = "CO2: ";
    let co2WithValueUnit = co2Heading + "<br>" + co2 + " ppm";
    document.querySelector(".text-top1.co2").innerHTML = co2WithValueUnit;

    let pm10 = data[5].parameters[5].value.toFixed(1);
    let pm10Heading = "PM10: ";
    let pm10WithValueUnit = pm10Heading + "<br>" + pm10 + " µg/m³";
    document.querySelector(".text-top1.pm10").innerHTML = pm10WithValueUnit;

    let co = data[5].parameters[6].value.toFixed(1);
    let coHeading = "CO: ";
    let coWithValueUnit = coHeading + "<br>" + co + " ppm";
    document.querySelector(".text-top1.co").innerHTML = coWithValueUnit;

    let no2 = data[5].parameters[7].value.toFixed(1);
    let no2Heading = "NO2: ";
    let no2WithValueUnit = no2Heading + "<br>" + no2 + " ppm";
    document.querySelector(".text-top1.no2").innerHTML = no2WithValueUnit;

    let pm25 = data[5].parameters[8].value.toFixed(1);
    let pm25Heading = "PM2.5: ";
    let pm25WithValueUnit = pm25Heading + "<br>" + pm25 + " µg/m³";
    document.querySelector(".text-top1.pm25").innerHTML = pm25WithValueUnit;

    let light = data[5].parameters[9].value.toFixed(1);
    let lightHeading = "Light: ";
    let lightWithValueUnit = lightHeading + "<br>" + light + " lux";
    document.querySelector(".text-top1.light").innerHTML = lightWithValueUnit;

    let rh = data[5].parameters[10].value.toFixed(1);
    let rhHeading = "Humidity: ";
    let rhWithValueUnit = rh + " %";
    document.querySelector(".skill.humidity .skill-name").innerHTML = rhHeading + rhWithValueUnit;

    let so2 = data[5].parameters[11].value.toFixed(1);
    let so2Heading = "SO2: ";
    let so2WithValueUnit = so2Heading + "<br>" + so2 + " ppm";
    document.querySelector(".text-top1.so2").innerHTML = so2WithValueUnit;

    let noise = data[5].parameters[12].value.toFixed(1);
    let noiseHeading = "Noise: ";
    let noiseWithValueUnit = noiseHeading + "<br>" + noise + " dB";
    document.querySelector(".text-top1.noise").innerHTML = noiseWithValueUnit;
  })
  .catch((error) => {
    console.error("There was a problem with the fetch operation:", error.message);
  });



  fetch(aqiEndpointURL, {
    method: "GET",
    headers: {
      Authorization: apiKey,
      "X-Forwarded-For": "14.143.117.134",
      "Content-Type": "application/json",
    },
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((responseData) => {
      // Assuming the AQI data is nested under "data"
      const aqiData = responseData;

      // console.log("AQI data: " + JSON.stringify(aqiData));

      // Extract AQI, pollutant, and remarks from aqiData
      let aqi = aqiData.value;
      let pollutant = aqiData.param;
      let remarks = aqiData.remark;
      let advisory = aqiData.advisory;
      const color = aqiData.color;

      const gradient = document.getElementById("GradientColor");
      if (gradient) {
        gradient
          .querySelector("stop[offset='0%']")
          .setAttribute("stop-color", color);
        gradient
          .querySelector("stop[offset='100%']")
          .setAttribute("stop-color", color);
      }

      // Update the circle's stroke with the new color
      const circle = document.querySelector("circle");
      if (circle) {
        circle.setAttribute("stroke", color);
      }

      // Display AQI

      let aqiElement = document.querySelector(".aqi_val");

      if (aqiElement) {
        aqiElement.innerHTML = "AQI: " + aqi;

        // Change text color based on AQI range
        if (aqi >= 0 && aqi <= 50) {
          aqiElement.style.color = "green";
        } else if (aqi > 50 && aqi <= 100) {
          aqiElement.style.color = "lightgreen";
        } else if (aqi > 100 && aqi <= 200) {
          aqiElement.style.color = "yellow";
        } else if (aqi > 200 && aqi <= 300) {
          aqiElement.style.color = "orange";
        } else if (aqi > 300 && aqi <= 400) {
          aqiElement.style.color = "lightred";
        } else {
          aqiElement.style.color = "red";
        }
      }

      // Display pollutant and remarks
      let pollutantElement = document.querySelector('.param p');
      if (pollutantElement) {
        pollutantElement.innerHTML = `<strong>Pollutant:</strong> ${pollutant}`;
      }

      let remarksElement = document.querySelector('.remark p');
      if (remarksElement) {
        remarksElement.innerHTML = `<strong>Remarks:</strong> ${remarks}`;
      }

      let advisoryElement = document.querySelector('.advisory p');
      if (advisoryElement) {
        advisoryElement.innerHTML = `<strong>Advisory:</strong> ${advisory}`;
      }

      // let nowcastElement = document.querySelector('.nowcast p');
      // if (nowcastElement) {
      //   nowcastElement.innerHTML = `<strong>NowCast:</strong> ${now}`;
      // }
      
    })
    .catch((error) => {
      console.error(
        "There was a problem with the fetch operation:",
        error.message
      );
    });




  fetch(feelsLikeEndpointURL, {
    method: "GET",
    headers: {
      Authorization: apiKey,
      "X-Forwarded-For": "14.143.117.134",
      "Content-Type": "application/json",
    },
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((feelsLikeData) => {
      // Assuming the Feels Like value is nested inside the object
      // const feelsLike = feelsLikeData.feelsLike; // Update this based on the actual structure of the response

      const feelsLike = feelsLikeData.feelsLike.toFixed(2);
      // Display Feels Like
      let feelsLikeElement = document.getElementsByClassName("api4")[0];
      if (feelsLikeElement) {
        feelsLikeElement.innerHTML = "Feels Like: " + feelsLike;
      }
    })
    .catch((error) => {
      console.error(
        "There was a problem with the fetch operation for Feels Like:",
        error.message
      );
    });

  // const headers = new Headers({
  //   Authorization: apiKey,
  //   "X-Forwarded-For": ipAddress,
  //   "Content-Type": "application/json",
  // });

  // const requestOptions = {
  //   method: "GET",
  //   headers: headers,
  // };

  // fetch(deviceURL, requestOptions)
  //   .then((response) => {
  //     if (response.status === 401) {
  //       throw new Error("Unauthorized: Please check your API key");
  //     }
  //     if (!response.ok) {
  //       // throw new Error(HTTP error! Status: ${response.status});
  //     }
  //     return response.json();
  //   })
  //   .then((data) => {
  //     console.log("Response Data:", data); // Log the response data to the console

  //     if (data && data.devices) {
  //       const devices = data.devices;
  //       const selectElement = document.getElementById("deviceSelect");

  //       devices.forEach((device) => {
  //         const optionElement = document.createElement("option");
  //         optionElement.value = device.devid; // Set the value to the device ID or any unique identifier
  //         optionElement.text = device.deviceName; // Set the display text to the device name
  //         selectElement.appendChild(optionElement);
  //       });

  //       // Add event listener to handle the change event
  //       selectElement.addEventListener("change", function () {
  //         // Get the selected device ID
  //         const selectedDeviceId = selectElement.value;

  //         // Redirect to the page with the selected device ID
  //         redirectToDevicePage(selectedDeviceId);
  //       });
  //     } else {
  //       console.error("Invalid response format:", data);
  //     }
  //   })
  //   .catch((error) => {
  //     console.error(
  //       "There was a problem with the fetch operation for devices:",
  //       error.message
  //     );
  //   });

  // // Function to redirect to the device page
  // function redirectToDevicePage(selectedDeviceId) {
  //   console.log(selectedDeviceId);

  //   // const devicePageUrl = http://127.0.0.1:5500/index.html?deviceId=${selectedDeviceId};
  //   // window.location.href = devicePageUrl;
  // }

  // // This part is for the redirected page logic
  // document.addEventListener("deviceSelect", function () {
  //   const urlParams = new URLSearchParams(window.location.search);
  //   const deviceId = urlParams.get("deviceId");
  //   const deviceIdPlaceholder = document.getElementById("deviceSelect");

  //   if (deviceId) {
  //     deviceIdPlaceholder.textContent = deviceId;
  //     fetchDataBasedOnDeviceId(deviceId);
  //   } else {
  //     console.error("No deviceId parameter found in the URL");
  //   }
  // });
}






api(); // Call the function to initiate the API request

function api() {
  const endpointURL = "https://app.myairmyhealth.com/airengine/no-auth";
  const postData = {
    userName: "elcita",
    password: "Ec9L8#Ca4cId$A",
  };

  fetch(endpointURL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(postData),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((data) => {
      token = data.token;
      //   console.log("Token generated is " + token);
      getData(token);
      setInterval(() => getData(token), 120000); 
    })
    .catch((error) => {
      console.error(
        "There was a problem with the fetch operation:",
        error.message
      );
    });
}