document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('login-form').addEventListener('submit', function (e) {
      e.preventDefault();
      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;

      // Check credentials and redirect
      handleLogin(username, password);
    });
  });

  function handleLogin(username, password) {
    if (username === 'elcita' && password === 'Ec9L8#Ca4cId$A') {
      console.log('Login successful. Redirecting...');
      window.location.href = '../ES1/index.html'; // Redirect to the specified page
    } else {
      alert('Invalid username or password. Please try again.');
    }
  }


